package com.example.android.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /* This method checks the Answers of the questions*/
    public void submitAnswer(View view)
    {
        CheckBox answerCheck14=(CheckBox) findViewById(R.id.answer14_checkBox);
        CheckBox answerCheck13=(CheckBox) findViewById(R.id.answer13_checkBox);
        CheckBox answerCheck11=(CheckBox) findViewById(R.id.answer11_checkBox);
        CheckBox answerCheck12=(CheckBox) findViewById(R.id.answer12_checkBox);
        boolean answer1=answerCheck14.isChecked() && !answerCheck12.isChecked() && !answerCheck13.isChecked() && !answerCheck11.isChecked();

        EditText answerCheck2=(EditText) findViewById(R.id.answer2_editText);
        String answer2=answerCheck2.getText().toString();

        RadioGroup answerCheck3=(RadioGroup) findViewById(R.id.answer3_radioGroup);
        boolean answer3=(R.id.answer31_radioButton == answerCheck3.getCheckedRadioButtonId());

        CheckBox answerCheck43=(CheckBox) findViewById(R.id.answer43_checkBox);
        CheckBox answerCheck41=(CheckBox) findViewById(R.id.answer41_checkBox);
        CheckBox answerCheck42=(CheckBox) findViewById(R.id.answer42_checkBox);
        CheckBox answerCheck44=(CheckBox) findViewById(R.id.answer44_checkBox);
        boolean answer4=answerCheck43.isChecked() && !answerCheck41.isChecked() && !answerCheck42.isChecked() && !answerCheck44.isChecked();

        CheckBox answerCheck54=(CheckBox) findViewById(R.id.answer54_checkBox);
        CheckBox answerCheck53=(CheckBox) findViewById(R.id.answer53_checkBox);
        CheckBox answerCheck52=(CheckBox) findViewById(R.id.answer52_checkBox);
        CheckBox answerCheck51=(CheckBox) findViewById(R.id.answer51_checkBox);
        boolean answer5=answerCheck54.isChecked() && !answerCheck51.isChecked() && !answerCheck52.isChecked() && !answerCheck53.isChecked();

        CheckBox answerCheck61=(CheckBox) findViewById(R.id.answer61_checkBox);
        CheckBox answerCheck62=(CheckBox) findViewById(R.id.answer62_checkBox);
        CheckBox answerCheck63=(CheckBox) findViewById(R.id.answer63_checkBox);
        CheckBox answerCheck64=(CheckBox) findViewById(R.id.answer64_checkBox);
        boolean answer6=answerCheck61.isChecked() && !answerCheck62.isChecked() && !answerCheck63.isChecked() && !answerCheck64.isChecked();
        int answers=checkAnswer(answer1 ,  answer2 , answer3 , answer4 , answer5 , answer6);
        if (answers == 6)
        Toast.makeText(this, "Yipppeeeee!! Your Score is " + answers  , Toast.LENGTH_SHORT ).show();
        else if (answers == 0)
            Toast.makeText(this, "Ooopppssss.. Your Score is " + answers + " You need to Improve" , Toast.LENGTH_SHORT ).show();
        else
            Toast.makeText(this, "Well Tried. Your Score is " + answers + " You can do Better" , Toast.LENGTH_SHORT ).show();
    }

    public int checkAnswer(boolean answer1 , String answer2 , boolean answer3  ,boolean answer4 ,boolean answer5 ,boolean answer6)
    {
        String correctAnswer = "502";
        int count=0;
        if(answer1)
            count++;
        if(answer2.equals(correctAnswer))
            count++;
        if(answer3)
            count++;
        if(answer4)
            count++;
        if(answer5)
            count++;
        if(answer6)
            count++;
        return count;

    }
}
