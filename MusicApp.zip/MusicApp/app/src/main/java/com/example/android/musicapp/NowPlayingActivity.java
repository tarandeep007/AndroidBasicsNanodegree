package com.example.android.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class NowPlayingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_now_playing);

        ImageView back=(ImageView)findViewById(R.id.back);
        ImageView play=(ImageView)findViewById(R.id.play);
        ImageView pause=(ImageView)findViewById(R.id.pause);
        ImageView forward=(ImageView)findViewById(R.id.forward);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast t=Toast.makeText(getApplicationContext(),"Previous song",Toast.LENGTH_SHORT);
                t.show();
            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast t=Toast.makeText(getApplicationContext(),"Play song",Toast.LENGTH_SHORT);
                t.show();
            }
        });
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast t=Toast.makeText(getApplicationContext(),"Pause song",Toast.LENGTH_SHORT);
                t.show();
            }
        });
        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast t=Toast.makeText(getApplicationContext(),"Play next song",Toast.LENGTH_SHORT);
                t.show();
            }
        });



        TextView library=(TextView) findViewById(R.id.library);

        library.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(NowPlayingActivity.this , LibraryActivity.class);
                startActivity(intent);
            }
        });

        TextView playlist=(TextView) findViewById(R.id.playlists);

        playlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(NowPlayingActivity.this , PlaylistsActivity.class);
                startActivity(intent);
            }
        });

        TextView artist=(TextView) findViewById(R.id.artist_textBox);

        artist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(NowPlayingActivity.this , ArtistActivity.class);
                startActivity(intent);
            }
        });

        TextView main=(TextView) findViewById(R.id.mainMenu);

        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(NowPlayingActivity.this , MainActivity.class);
                startActivity(intent);
            }
        });
        TextView payment=(TextView) findViewById(R.id.payment);
        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(NowPlayingActivity.this , PaymentActivity.class);
                startActivity(intent);
            }
        });
    }
}
