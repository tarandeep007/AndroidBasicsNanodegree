package com.example.android.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ArtistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artist);

        TextView nowPlaying=(TextView) findViewById(R.id.nowPlaying);
        nowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ArtistActivity.this , NowPlayingActivity.class);
                startActivity(intent);
            }
        });

        TextView playlist=(TextView) findViewById(R.id.playlists);
        playlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ArtistActivity.this , PlaylistsActivity.class);
                startActivity(intent);
            }
        });

        TextView library=(TextView) findViewById(R.id.library);
        library.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ArtistActivity.this , LibraryActivity.class);
                startActivity(intent);
            }
        });

        TextView music=(TextView) findViewById(R.id.mainMenu);
        music.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ArtistActivity.this , MainActivity.class);
                startActivity(intent);
            }
        });
        TextView payment=(TextView) findViewById(R.id.payment);
        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ArtistActivity.this , PaymentActivity.class);
                startActivity(intent);
            }
        });
    }
}
