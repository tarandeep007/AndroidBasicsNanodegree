package com.example.android.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView nowPlaying=(TextView) findViewById(R.id.nowPlaying);

        nowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this , NowPlayingActivity.class);
                startActivity(intent);
            }
        });

        TextView library=(TextView) findViewById(R.id.library);

        library.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this , LibraryActivity.class);
                startActivity(intent);
            }
        });

        TextView playlist=(TextView) findViewById(R.id.playlists);

        playlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this , PlaylistsActivity.class);
                startActivity(intent);
            }
        });

        TextView artist=(TextView) findViewById(R.id.artist_textBox);
        artist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this , ArtistActivity.class);
                startActivity(intent);
            }
        });
        TextView payment=(TextView) findViewById(R.id.payment);
        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this , PaymentActivity.class);
                startActivity(intent);
            }
        });
    }


}
