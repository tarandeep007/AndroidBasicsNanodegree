package com.example.android.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class LibraryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        TextView playlists=(TextView) findViewById(R.id.playlists);

        playlists.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LibraryActivity.this , PlaylistsActivity.class);
                startActivity(intent);
            }
        });

        TextView nowPlaying=(TextView) findViewById(R.id.nowPlaying);

        nowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LibraryActivity.this , NowPlayingActivity.class);
                startActivity(intent);
            }
        });

        TextView artist=(TextView) findViewById(R.id.artist_textBox);

        artist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LibraryActivity.this , ArtistActivity.class);
                startActivity(intent);
            }
        });

        TextView main=(TextView) findViewById(R.id.mainMenu);

        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LibraryActivity.this , MainActivity.class);
                startActivity(intent);
            }
        });
        TextView payment=(TextView) findViewById(R.id.payment);
        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LibraryActivity.this , PaymentActivity.class);
                startActivity(intent);
            }
        });
    }
}
