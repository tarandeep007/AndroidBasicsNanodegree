package com.example.android.habittrackerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;

/**
 * Created by asus pc on 16-Oct-17.
 */

public class HBTrackerDbHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    static final String NAME = "HabitTracker.db";
    public HBTrackerDbHelper(Context context)
    {
        super(context, NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        final String SQL_CREATE_HABIT_TABLE = "CREATE TABLE " + HBTracker.Habit.TABLE_NAME + " (" +
                HBTracker.Habit.ID + " INTEGER PRIMARY KEY," +
                HBTracker.Habit.COLUMN_NAME + " TEXT UNIQUE NOT NULL, " +
                HBTracker.Habit.COLUMN_HABIT + " TEXT NOT NULL, "  +
                HBTracker.Habit.COLUMN_FREQ +"INTEGER NOT NULL,"+
                " );";
        sqLiteDatabase.execSQL(SQL_CREATE_HABIT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1)
    {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + HBTracker.Habit.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }
    // Insert data in the table
    public boolean insertData(int id, String name, String location, String habit, int frquency) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(HBTracker.Habit.ID, id);
        contentValues.put(HBTracker.Habit.COLUMN_NAME, name);
        contentValues.put(HBTracker.Habit.COLUMN_HABIT, habit);
        contentValues.put(HBTracker.Habit.COLUMN_FREQ,frquency);
        db.insert(HBTracker.Habit.TABLE_NAME, null, contentValues);
        db.close();
        return true;
    }
    // Get data from the table
    public Cursor getData(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.rawQuery("SELECT * from " + HBTracker.Habit.TABLE_NAME +
                " WHERE name=" + name, null);
        db.close();
        return result;
    }
    // Delete all table entries
    public int deleteAllEntries() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(HBTracker.Habit.TABLE_NAME, null, null);
    }
    // Delete the database
    public boolean deleteDatabase(Context context) {
        return context.deleteDatabase(HBTracker.Habit.TABLE_NAME);
    }
    // Update data in the table
    public boolean updateData(int id, String name, String location, String habit, int frequnecy) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(HBTracker.Habit.ID, id);
        contentValues.put(HBTracker.Habit.COLUMN_NAME, name);
        contentValues.put(HBTracker.Habit.COLUMN_HABIT, habit);
        contentValues.put(HBTracker.Habit.COLUMN_FREQ, frequnecy);
        db.update(HBTracker.Habit.TABLE_NAME, contentValues, " id = ? ",
                new String[]{Integer.toString(id)});
        db.close();
        return true;
    }
}
