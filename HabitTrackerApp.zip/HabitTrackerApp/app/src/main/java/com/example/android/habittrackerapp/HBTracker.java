package com.example.android.habittrackerapp;

import android.provider.BaseColumns;

/**
 * Created by asus pc on 16-Oct-17.
 */

public class HBTracker
{
    public static final class Habit implements BaseColumns
    {
        public static final String ID = "_id";
        public static final String TABLE_NAME = "HabitTracher";
        public static final String COLUMN_NAME = "Name";
        public static final String COLUMN_HABIT = "Habit";
        public static final String COLUMN_FREQ = "Frequency";
    }
}
