package com.example.android.reportcard;

/**
 * Created by asus pc on 22-Aug-17.
 */

public class ReportCard
{
    private char Sec;
    private String fullName;
    private int Maths;
    private int Science;
    private int Software;
    private int Toc;
    private int Total;

    public ReportCard(char sec,String fullname,int M1,int M2,int M3,int M4)
    {
        fullName= fullname;
        Sec=sec;
        Maths=M1;
        Science=M2;
        Software=M3;
        Toc=M4;
    }
    public String getfullName() {
        return fullName;
    }
    public void setfullName(String fullname) {
        fullName=fullname;
    }
    public char getSec() {
        return Sec;
    }
    public void setSec(char sec) {
        Sec=sec;
    }
    public int getMaths() {
        return Maths;
    }
    public void setMaths(int score) {
        Maths=score;
    }
    public int getcience() {
        return Science;
    }
    public void setScience(int score) {
        Science=score;
    }
    public int getSoftware() {
        return Software;
    }
    public void setSoftware(int score) {
        Software=score;
    }
    public int getToc() {
        return Toc;
    }
    public void setToc(int score) {
        Toc=score;
    }
    public int getTotal() {
        Total = Maths + Science + Software + Toc;
        return Total;
    }
    public double getpercent() {
        return Total/4;
    }
    @Override
    public String toString() {
        return "Result { " + "MATHS = " + Maths + "\nSCIENCE = " + Science + "\nSOFTWARE = " + Software + "\nTOC = " + Toc + "\nTOTAL = " + Total + " } ";
    }
}
