package com.example.android.boollistingapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

import static com.example.android.boollistingapp.MainActivity.isNetworkAvailable;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        String find = getIntent().getStringExtra("data");
        if (!isNetworkAvailable(ListActivity.this)) {
            Toast.makeText(ListActivity.this, "Please Check Your Internet Connection.", Toast.LENGTH_SHORT).show();
            return;
        }
        String url = "https://www.googleapis.com/books/v1/volumes?q=" + find + "&maxResults=20";
        new NetworkActivity().execute(url);
    }

    private class NetworkActivity extends AsyncTask<String, Void, JSONObject> {
        private ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ListActivity.this);
            pd.setMessage("Loading");
            pd.show();
        }

        @Override
        protected JSONObject doInBackground(String... address) {
            JSONObject array = null;
            URL url = createUrl(address[0]);
            String result = "";
            try {
                result = makeHttpRequest(url);
                Log.v("Main", "" + result);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                array = new JSONObject(result);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return array;
        }

        private URL createUrl(String stringUrl) {
            URL url = null;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                Log.e("URL", "Error with creating URL", exception);
                return null;
            }
            return url;
        }

        private String makeHttpRequest(URL url) throws IOException {
            String jsonResponse = "";
            HttpURLConnection urlConnection = null;
            InputStream inputStream = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setReadTimeout(10000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.connect();
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (inputStream != null) {
                    // function must handle java.io.IOException here
                    inputStream.close();
                }
            }
            return jsonResponse;
        }

        private String readFromStream(InputStream inputStream) throws IOException {
            StringBuilder output = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                BufferedReader reader = new BufferedReader(inputStreamReader);
                String line = reader.readLine();
                while (line != null) {
                    output.append(line);
                    line = reader.readLine();
                }
            }
            return output.toString();
        }

        @Override
        protected void onPostExecute(JSONObject object) {
            pd.dismiss();
            if (object.optString("totalItems").equals("0")) {
                Toast.makeText(ListActivity.this, "No Results Found!", Toast.LENGTH_SHORT).show();
                return;
            }
            JSONArray array = object.optJSONArray("items");
            JSONObject obj = null;
            final ArrayList<Books> books = new ArrayList<>();
            for (int i = 0; i < array.length(); i++) {
                obj = array.optJSONObject(i).optJSONObject("volumeInfo");
                books.add(new Books(obj.optString("title"), obj.optString("authors"), obj.optString("publishedDate"), obj.optString("pageCount"),obj.optString("previewLink")));
            }
            ListView list = (ListView) findViewById(R.id.list);
            BooksAdapter adapter = new BooksAdapter(ListActivity.this, books);
            list.setAdapter(adapter);
            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                    // Get the {@link Word} object at the given position the user clicked on
                    Books book = books.get(position);

                    // Create and setup the {@link MediaPlayer} for the audio resource associated
                    // with the current word
                    startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(book.getLink())));
                }
            });
        }
    }
}
