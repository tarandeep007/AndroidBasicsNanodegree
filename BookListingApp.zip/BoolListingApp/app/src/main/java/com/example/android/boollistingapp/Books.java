package com.example.android.boollistingapp;

import org.json.JSONArray;
import org.json.JSONException;

/**
 * Created by asus pc on 12-Oct-17.
 */

public class Books {
    private String mTitle;
    private String mAuthors;
    private String mDate;
    private String mPages;
    private String mLink;

    public Books(String title, String authors, String date, String pages,String link) {
        mTitle = title;
        mAuthors = authors;
        mDate = date;
        mPages = pages;
        mLink=link;
    }

    public String getDate() {
        return mDate;
    }

    public String getPages() {
        try {
            int n = Integer.parseInt(mPages);
        } catch (NumberFormatException e) {
            return mPages;
        }
        return mPages + " Pages";
    }

    public String getAuthors() {
        JSONArray array=null;
        try {
            array=new JSONArray(mAuthors);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        String auth= "";
        for(int i=0;i<array.length();i++)
        {
            auth+=array.optString(i)+"\n";
        }
        return auth;
    }

    public String getTitle() {
        return mTitle;
    }

    public String getLink() {
        return mLink;
    }
}
