package com.example.android.guideapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class placesFragment extends Fragment {


    public placesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

        final ArrayList<Details> place=new ArrayList<>();

        place.add(new Details(R.string.place_one,R.string.review_one, R.drawable.goa));
        place.add(new Details(R.string.place_two, R.string.review_two, R.drawable.kashmir));
        place.add(new Details(R.string.place_three , R.string.review_three, R.drawable.banglore));
        place.add(new Details(R.string.place_four, R.string.review_four, R.drawable.leh));
        place.add(new Details(R.string.place_five, R.string.review_five, R.drawable.shimla));
        place.add(new Details(R.string.place_six, R.string.review_six, R.drawable.darjeeling));
        place.add(new Details(R.string.place_seven,R.string.review_seven, R.drawable.udaipur));
        place.add(new Details(R.string.place_eight,R.string.review_eight, R.drawable.mumbai));

        Adapter adapter= new Adapter(getActivity(),place,R.color.category_places);
        ListView listView=(ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        return rootView;
    }

}
