package com.example.android.guideapp;

/**
 * Created by asus pc on 28-Aug-17.
 */

public class Details
{
    private int mText;
    private int mReview;
    private int mImageResourceId=No_Image_Provided;

    private static final int No_Image_Provided=-1;

    public Details(int text, int review)
    {
        mText=text;
        mReview = review;
    }

    public Details(int text, int review, int imageResourceId)
    {
        mText=text;
        mReview=review;
        mImageResourceId=imageResourceId;
    }

    public int getText()
    {
        return mText;
    }
    public int getReview()
    {
        return mReview;
    }
    public int getImageId() {
        return mImageResourceId;
    }
    public boolean hasImage()
    {
        return mImageResourceId!=No_Image_Provided;
    }

}
