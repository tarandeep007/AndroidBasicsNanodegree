package com.example.android.guideapp;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class FragmentAdapter extends FragmentPagerAdapter {

    private Context mContext;

    public FragmentAdapter(Context context , FragmentManager fragmentManager)
    {
        super(fragmentManager);
        mContext=context;
        // Required empty public constructor
    }

    public Fragment getItem(int pos)
    {
        if (pos == 0) {
            return new placesFragment();
        } else if (pos == 1) {
            return new eventsFragment();
        } else if (pos == 2) {
            return new foodsFragment();
        } else {
            return new reviewsFragment();
        }
    }

    /**
     * Return the total number of pages.
     */
    @Override
    public int getCount() {
        return 4;
    }

    @Override
    public CharSequence getPageTitle(int pos) {
        if (pos == 0) {
            return mContext.getString(R.string.places);
        } else if (pos == 1) {
            return mContext.getString(R.string.events);
        } else if (pos == 2) {
            return mContext.getString(R.string.restaurants);
        } else {
            return mContext.getString(R.string.reviews);
        }

    }
}
