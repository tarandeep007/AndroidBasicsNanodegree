package com.example.android.guideapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class foodsFragment extends Fragment {


    public foodsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        View rootView = inflater.inflate(R.layout.word_list, container, false);

        final ArrayList<Details> food=new ArrayList<>();

        food.add(new Details(R.string.food_one,R.string.food_review_one, R.drawable.food));
        food.add(new Details(R.string.food_two, R.string.food_review_two, R.drawable.food));
        food.add(new Details(R.string.food_three , R.string.food_review_three, R.drawable.food));
        food.add(new Details(R.string.food_four, R.string.food_review_four, R.drawable.food));
        food.add(new Details(R.string.food_five, R.string.food_review_five, R.drawable.food));
        food.add(new Details(R.string.food_six, R.string.food_review_six, R.drawable.food));
        food.add(new Details(R.string.food_seven,R.string.food_review_seven,R.drawable.food));
        food.add(new Details(R.string.food_eight,R.string.food_review_eight, R.drawable.food));

        Adapter adapter= new Adapter(getActivity(),food,R.color.category_food);
        ListView listView=(ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);

        return rootView;
    }

}
