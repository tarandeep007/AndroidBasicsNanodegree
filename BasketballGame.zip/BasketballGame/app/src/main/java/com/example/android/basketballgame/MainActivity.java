package com.example.android.basketballgame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int scoreA = 0;
    int scoreB = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /* Inceremnt the score value by 3*/
    public void increment3A(View view)
    {
        scoreA=scoreA+3;
        displayA(scoreA);
    }

    /* Inceremnt the score value by 2*/
    public void increment2A(View view)
    {
        scoreA=scoreA+2;
        displayA(scoreA);
    }

    /* Inceremnt the score value by 1*/
    public void freethrowA(View view)
    {
        scoreA=scoreA+1;
        displayA(scoreA);
    }

    /*this method displays the score*/
    public void displayA(int number)
    {
        TextView scoreTextView=(TextView) findViewById(R.id.scoreA);
        scoreTextView.setText(""+number);
    }

    /* Inceremnt the score value by 3*/
    public void increment3B(View view)
    {
        scoreB=scoreB+3;
        displayB(scoreB);
    }

    /* Inceremnt the score value by 2*/
    public void increment2B(View view)
    {
        scoreB=scoreB+2;
        displayB(scoreB);
    }

    /* Inceremnt the score value by 1*/
    public void freethrowB(View view)
    {
        scoreB=scoreB+1;
        displayB(scoreB);
    }

    /*this method displays the score*/
    public void displayB(int number)
    {
        TextView scoreTextView=(TextView) findViewById(R.id.scoreB);
        scoreTextView.setText(""+number);
    }

    /*ths method resets the score to 0*/

    public void reset(View view)
    {
        scoreA = 0;
        scoreB = 0;
        displayreset(scoreA,scoreB);
    }

    public void displayreset(int number1, int number2)
    {
        TextView scoreTextViewA=(TextView) findViewById(R.id.scoreA);
        scoreTextViewA.setText(""+number1);
        TextView scoreTextViewB=(TextView) findViewById(R.id.scoreB);
        scoreTextViewB.setText(""+number2);
    }


}
