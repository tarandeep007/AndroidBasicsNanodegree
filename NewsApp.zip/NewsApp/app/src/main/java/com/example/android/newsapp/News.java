package com.example.android.newsapp;

import java.util.Date;

/**
 * Created by asus pc on 16-Oct-17.
 */

public class News
{
    private String mTitle;
    private String mDesc;
    private String mCateg;
    private Date mPublishDate;
    private String mAuthor;
    private String mLink;
    public News(String title, String description, String category, String author, String lonk, Date publishedDate) {
        mTitle = title;
        mDesc = description;
        mCateg = category;
        mAuthor=author;
        mLink=lonk;
        mPublishDate = publishedDate;
    }
    public String getTitle() {
        return mTitle;
    }

    public String getDescription() {
        return mDesc;
    }

    public String getCategory() {
        return mCateg;
    }

    public String getmAuthor() {
        return mAuthor;
    }

    public String getMlink() {
        return mLink;
    }

    public Date getPublishedDate() {
        return mPublishDate;
    }

}
