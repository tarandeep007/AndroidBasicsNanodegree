package com.example.android.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by asus pc on 22-Oct-17.
 */

public class DBHelper extends SQLiteOpenHelper
{
    private static final int VERSION = 1;

    static final String NAME = "inventory.db";

    public DBHelper(Context context) {
        super(context, NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String SQL_CREATE_HABIT_TABLE = "CREATE TABLE " + Contract.InventoryEntries.TABLE_NAME + " (" +
                Contract.InventoryEntries.COLUMN_ID + " INTEGER PRIMARY KEY," +
                Contract.InventoryEntries.COLUMN_PRODUCT_NAME + " TEXT NOT NULL, " +
                Contract.InventoryEntries.COLUMN_QUANTITY + " INTEGER NOT NULL, " +
                Contract.InventoryEntries.COLUMN_PRICE + " INTEGER NOT NULL," +
                Contract.InventoryEntries.COLUMN_IMAGE + " BLOB NOT NULL)";
        sqLiteDatabase.execSQL(SQL_CREATE_HABIT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Contract.InventoryEntries.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    // Insert data in the table
    public boolean insertData(String productName, int quantity, int price,byte[] image) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Contract.InventoryEntries.COLUMN_PRODUCT_NAME, productName);
        contentValues.put(Contract.InventoryEntries.COLUMN_QUANTITY, quantity);
        contentValues.put(Contract.InventoryEntries.COLUMN_PRICE, price);
        contentValues.put(Contract.InventoryEntries.COLUMN_IMAGE, image);
        db.insert(Contract.InventoryEntries.TABLE_NAME, null, contentValues);
        return true;
    }

    // Get data from the table
    public Cursor getData(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * from " + Contract.InventoryEntries.TABLE_NAME +
                " WHERE name=\"" + name + "\"", null);
        return res;
    }
    // Delete all entries
    public int deleteEntries() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Contract.InventoryEntries.TABLE_NAME, null, null);
    }

    // Delete one table entry
    public boolean deleteData(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Contract.InventoryEntries.TABLE_NAME, "name=?", new String[]{name}) > 0;
    }

    // Update data in the table
    public void updateData(String name, int quantity, int change) {
        SQLiteDatabase db = this.getWritableDatabase();
        String strSQL = "UPDATE " + Contract.InventoryEntries.TABLE_NAME + " SET quantity = "
                + (quantity + change) + " WHERE name = \"" + name + "\"";
        db.execSQL(strSQL);
    }

    public ArrayList<String> getAllData() {
        ArrayList<String> productList = new ArrayList<String>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor getList = db.rawQuery("SELECT * FROM " + Contract.InventoryEntries.TABLE_NAME, null);
        getList.moveToFirst();
        while (getList.isAfterLast() == false) {
            String productName = getList.getString(getList.getColumnIndex(Contract.InventoryEntries.COLUMN_PRODUCT_NAME));
            int quantity = getList.getInt(getList.getColumnIndex(Contract.InventoryEntries.COLUMN_QUANTITY));
            int price = getList.getInt(getList.getColumnIndex(Contract.InventoryEntries.COLUMN_PRICE));
            productList.add(productName + "\n" + "Quantity: " + quantity + "\n" + "Price: $" + price);
            getList.moveToNext();
        }
        return productList;
    }
}
