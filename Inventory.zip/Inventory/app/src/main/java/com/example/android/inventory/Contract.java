package com.example.android.inventory;

import android.provider.BaseColumns;

/**
 * Created by asus pc on 22-Oct-17.
 */

public class Contract
{
    public static final class InventoryEntries implements BaseColumns {

        public static final String COLUMN_ID = "Id";
        public static final String TABLE_NAME = "InventoryApp";
        public static final String COLUMN_PRODUCT_NAME = "Name";
        public static final String COLUMN_QUANTITY = "Quantity";
        public static final String COLUMN_IMAGE="Image";
        public static final String COLUMN_PRICE = "Price";
    }
}
